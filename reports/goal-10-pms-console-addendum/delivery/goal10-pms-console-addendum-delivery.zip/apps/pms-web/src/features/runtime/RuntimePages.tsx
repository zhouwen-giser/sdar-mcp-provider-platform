import { useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import {
  Button,
  CodeOrJsonViewer,
  ConfirmDialog,
  DataTable,
  DeferredCapability,
  FilterBar,
  FormField,
  KeyValueList,
  MetricCard,
  QuerySurface,
  StatusBadge,
  StepProgress,
  Tabs,
  Timeline,
  Wizard,
} from "../../components/ui.js";
import {
  useConfigurationDrafts,
  useCreateDeployment,
  useDeployment,
  useDeployments,
  useProcess,
  useProcesses,
  useProviders,
  useRuntimeCommand,
  useScaleDeployment,
  currentEnvironmentScope,
} from "../../queries/hooks.js";
import { useAuditEvents } from "../../queries/hooks.js";
import { useClientWorkspace, useClientWorkspaceStore } from "../../client-workspace/context.js";
import { navigate } from "../../app/navigation.js";
import {
  ContractBoundaryNote,
  DeferredForm,
  MutationFeedback,
  ProductPage,
} from "../shared/product-components.js";
import { dataMode } from "../../gateways/factory.js";

export function RuntimeDeploymentListPage() {
  const query = useDeployments();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const rows = (query.data ?? []).filter(
    (item) =>
      `${item.deploymentId} ${item.providerId} ${item.environment}`
        .toLowerCase()
        .includes(search.toLowerCase()) &&
      (status === "all" || item.status === status),
  );
  return (
    <ProductPage
      title="Runtime Deployments"
      description="Desired/Observed Revision、Desired State 和当前部署状态的冻结查询。"
      classification="FROZEN_API"
      actions={
        <Button variant="primary" onClick={() => navigate("/runtime/deployments/new")}>
          创建 Deployment
        </Button>
      }
    >
      <div className="metrics-row">
        <MetricCard label="总数" value={query.data?.length ?? "—"} />
        <MetricCard
          label="Active"
          value={query.data?.filter((x) => x.status === "ACTIVE").length ?? "—"}
        />
        <MetricCard label="未收敛" value={query.data?.filter((x) => !x.converged).length ?? "—"} />
        <MetricCard
          label="Stopped"
          value={query.data?.filter((x) => x.desiredState === "stopped").length ?? "—"}
        />
      </div>
      <FilterBar>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Deployment / Provider / Environment"
        />
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="all">全部状态</option>
          {["REQUESTED", "STARTING", "ACTIVE", "STOPPED", "DEGRADED", "FAILED"].map((v) => (
            <option key={v}>{v}</option>
          ))}
        </select>
      </FilterBar>
      <section className="panel">
        <QuerySurface query={query}>
          {() => (
            <DataTable
              columns={[
                "Deployment",
                "Provider",
                "Environment",
                "Desired",
                "Status",
                "Revision",
                "Converged",
              ]}
              rows={rows.map((item) => [
                <button
                  className="table-link"
                  onClick={() =>
                    navigate(`/runtime/deployments/${item.providerId}/${item.deploymentId}`)
                  }
                >
                  {item.deploymentId}
                </button>,
                item.providerId,
                item.environment,
                `${item.desiredState}/${item.desiredReplicas}`,
                <StatusBadge status={item.status} />,
                `${item.observedRevision}/${item.desiredRevision}`,
                item.converged ? "Yes" : "No",
              ])}
            />
          )}
        </QuerySurface>
      </section>
    </ProductPage>
  );
}

const deploymentSteps = [
  "Provider",
  "Runtime Release",
  "Database Profile",
  "Configuration Target",
  "Placement",
  "影响与提交",
  "Intent Result",
];
export function RuntimeDeploymentCreatePage() {
  const providers = useProviders();
  const [params] = useSearchParams();
  const mutation = useCreateDeployment();
  const workspace = useClientWorkspaceStore();
  const mockMode = dataMode() === "mock";
  const environment = currentEnvironmentScope()[0] ?? "";
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState({
    deploymentId: mockMode ? "deploy-new-001" : "",
    providerId: params.get("providerId") ?? (mockMode ? "ugv-prod-001" : ""),
    environment,
    runtimeVersion: mockMode ? "2.0.0-rc.1" : "",
    databaseProfileId: mockMode ? "db-profile-001" : "",
    configProfileId: mockMode
      ? "production:runtime_deployment:deploy-new-001:runtime:runtime-main"
      : "",
    adapterEndpoint: mockMode ? "127.0.0.1:8101" : "",
    desiredReplicas: 1 as 0 | 1,
  });
  const submit = () =>
    mutation.mutate(draft, {
      onSuccess: (intent) => {
        workspace.recordIntent(
          "runtime.create",
          intent.deployment.deploymentId,
          intent.operationId,
        );
        setStep(6);
      },
    });
  return (
    <ProductPage
      title="创建 RuntimeDeployment"
      description="六步前端向导，最终仅调用 createRuntimeDeployment；不编排数据库或配置创建。"
      classification="WEB_COMPOSED"
    >
      <Wizard>
        <StepProgress steps={deploymentSteps} current={step} />
        <section className="wizard-body">
          <h2>{deploymentSteps[step]}</h2>
          {step === 0 ? (
            <QuerySurface query={providers}>
              {(items) => (
                <FormField label="Provider">
                  <select
                    value={draft.providerId}
                    onChange={(e) => setDraft((x) => ({ ...x, providerId: e.target.value }))}
                  >
                    {items.map((x) => (
                      <option key={x.providerId}>{x.providerId}</option>
                    ))}
                  </select>
                </FormField>
              )}
            </QuerySurface>
          ) : null}
          {step === 1 ? (
            <FormField label="Runtime Version">
              <select
                value={draft.runtimeVersion}
                onChange={(e) => setDraft((x) => ({ ...x, runtimeVersion: e.target.value }))}
              >
                <option>2.0.0-rc.1</option>
                <option>1.9.4</option>
              </select>
            </FormField>
          ) : null}
          {step === 2 ? (
            <>
              <FormField label="Database Profile ID">
                <input
                  value={draft.databaseProfileId}
                  onChange={(e) => setDraft((x) => ({ ...x, databaseProfileId: e.target.value }))}
                />
              </FormField>
              <p className="field-note">Database Profile 管理未冻结；这里只传递现有 ID。</p>
            </>
          ) : null}
          {step === 3 ? (
            <FormField label="Config Profile ID">
              <input
                value={draft.configProfileId}
                onChange={(e) => setDraft((x) => ({ ...x, configProfileId: e.target.value }))}
              />
            </FormField>
          ) : null}
          {step === 4 ? (
            <div className="grid-two">
              <FormField label="Environment">
                {mockMode ? (
                  <select
                    value={draft.environment}
                    onChange={(e) => setDraft((x) => ({ ...x, environment: e.target.value }))}
                  >
                    <option>production</option>
                    <option>staging</option>
                  </select>
                ) : (
                  <input
                    value={draft.environment}
                    placeholder="真实 Environment ID"
                    onChange={(e) => setDraft((x) => ({ ...x, environment: e.target.value }))}
                  />
                )}
              </FormField>
              <FormField label="Desired Replicas">
                <select
                  value={draft.desiredReplicas}
                  onChange={(e) =>
                    setDraft((x) => ({ ...x, desiredReplicas: Number(e.target.value) as 0 | 1 }))
                  }
                >
                  <option value={1}>1 · running</option>
                  <option value={0}>0 · stopped</option>
                </select>
              </FormField>
              <FormField label="Adapter Endpoint">
                <input
                  value={draft.adapterEndpoint}
                  onChange={(e) => setDraft((x) => ({ ...x, adapterEndpoint: e.target.value }))}
                />
              </FormField>
            </div>
          ) : null}
          {step === 5 ? (
            <div className="grid-two">
              <section>
                <FormField label="Deployment ID">
                  <input
                    value={draft.deploymentId}
                    onChange={(e) =>
                      setDraft((x) => ({
                        ...x,
                        deploymentId: e.target.value,
                        configProfileId: `${x.environment}:runtime_deployment:${e.target.value}:runtime:runtime-main`,
                      }))
                    }
                  />
                </FormField>
                <CodeOrJsonViewer value={draft} />
              </section>
              <section className="impact-box">
                <h3>合同约束</h3>
                <ul>
                  <li>desiredReplicas 只能为 0 或 1</li>
                  <li>响应为 202 Intent，包含 operationId 与 Deployment snapshot</li>
                  <li>不保证立即 ACTIVE</li>
                  <li>后续进度由 Deployment、RuntimeProcess、Audit 组合展示</li>
                </ul>
              </section>
            </div>
          ) : null}
          {step === 6 && mutation.data ? (
            <div className="success-result">
              <StatusBadge status="ACCEPTED" />
              <h3>Intent accepted</h3>
              <KeyValueList
                entries={[
                  ["Operation ID", mutation.data.operationId],
                  ["Deployment", mutation.data.deployment.deploymentId],
                  ["Status", mutation.data.deployment.status],
                  ["Desired Revision", mutation.data.deployment.desiredRevision],
                ]}
              />
              <Button
                variant="primary"
                onClick={() =>
                  navigate(
                    `/runtime/deployments/${mutation.data?.deployment.providerId}/${mutation.data?.deployment.deploymentId}`,
                  )
                }
              >
                查看生命周期
              </Button>
            </div>
          ) : null}
          <MutationFeedback mutation={mutation} />
        </section>
        <footer className="wizard-actions">
          <Button
            disabled={step === 0 || step === 6 || mutation.isPending}
            onClick={() => setStep((x) => x - 1)}
          >
            上一步
          </Button>
          {step < 5 ? (
            <Button variant="primary" onClick={() => setStep((x) => x + 1)}>
              下一步
            </Button>
          ) : step === 5 ? (
            <Button variant="primary" busy={mutation.isPending} onClick={submit}>
              提交创建 Intent
            </Button>
          ) : null}
        </footer>
      </Wizard>
    </ProductPage>
  );
}

type DeploymentSection =
  | "overview"
  | "edit"
  | "reconciliation"
  | "instances"
  | "configuration"
  | "activity"
  | "upgrade"
  | "scale";
export function RuntimeDeploymentDetailPage({
  section = "overview",
}: {
  readonly section?: DeploymentSection;
}) {
  const { providerId = "", deploymentId = "" } = useParams();
  const deployment = useDeployment(providerId, deploymentId);
  const processes = useProcesses([[providerId, deploymentId]]);
  const drafts = useConfigurationDrafts();
  const audit = useAuditEvents({ subjectId: deploymentId });
  const workspace = useClientWorkspace();
  const workspaceStore = useClientWorkspaceStore();
  const start = useRuntimeCommand("start");
  const stop = useRuntimeCommand("stop");
  const restart = useRuntimeCommand("restart");
  const reconcile = useRuntimeCommand("reconcile");
  const scale = useScaleDeployment();
  const [confirm, setConfirm] = useState<"stop" | "restart" | "scale0" | null>(null);
  const [replicas, setReplicas] = useState<0 | 1>(1);
  const command = (kind: "start" | "stop" | "restart" | "reconcile") => {
    const mutation = { start, stop, restart, reconcile }[kind];
    const item = deployment.data;
    if (!item) return;
    mutation.mutate(
      {
        deploymentId: item.deploymentId,
        providerId: item.providerId,
        expectedDesiredRevision: item.desiredRevision,
      },
      {
        onSuccess: (intent) =>
          workspaceStore.recordIntent(`runtime.${kind}`, item.deploymentId, intent.operationId),
      },
    );
  };
  return (
    <QuerySurface query={deployment}>
      {(item) => (
        <ProductPage
          title={item.deploymentId}
          description={`${item.providerId} · ${item.environment} · desired revision ${item.desiredRevision}`}
          classification={section === "upgrade" ? "DEFERRED" : "FROZEN_API"}
          actions={
            <>
              <Button
                disabled={item.desiredState === "running"}
                busy={start.isPending}
                onClick={() => command("start")}
              >
                Start
              </Button>
              <Button
                variant="danger"
                disabled={item.desiredState === "stopped"}
                onClick={() => setConfirm("stop")}
              >
                Stop
              </Button>
              <Button onClick={() => setConfirm("restart")}>Restart</Button>
              <Button
                variant="primary"
                busy={reconcile.isPending}
                onClick={() => command("reconcile")}
              >
                Reconcile
              </Button>
            </>
          }
        >
          <Tabs
            current={section}
            onChange={(id) =>
              navigate(`/runtime/deployments/${item.providerId}/${item.deploymentId}/${id}`)
            }
            items={[
              { id: "overview", label: "概览" },
              { id: "reconciliation", label: "调和" },
              { id: "instances", label: "Instances" },
              { id: "configuration", label: "配置" },
              { id: "activity", label: "Activity" },
              { id: "scale", label: "Scale" },
              { id: "upgrade", label: "Upgrade" },
            ]}
          />
          {section === "overview" ? (
            <>
              <div className="metrics-row">
                <MetricCard label="Status" value={<StatusBadge status={item.status} />} />
                <MetricCard
                  label="Desired"
                  value={`${item.desiredState}/${item.desiredReplicas}`}
                />
                <MetricCard
                  label="Revision"
                  value={`${item.observedRevision}/${item.desiredRevision}`}
                  hint={item.converged ? "converged" : "pending"}
                />
                <MetricCard label="Runtime" value={item.runtimeVersion} />
              </div>
              <div className="grid-two">
                <section className="panel">
                  <h2>Deployment fields</h2>
                  <KeyValueList
                    entries={[
                      ["Provider", item.providerId],
                      ["Environment", item.environment],
                      ["Database Profile", item.databaseProfileId],
                      ["Config Profile", item.configProfileId],
                      ["Desired State", item.desiredState],
                      ["Desired Replicas", item.desiredReplicas],
                      ["Desired Revision", item.desiredRevision],
                      ["Observed Revision", item.observedRevision],
                    ]}
                  />
                </section>
                <section className="panel">
                  <h2>Intent semantics</h2>
                  <Timeline
                    items={[
                      {
                        label: "Desired intent",
                        meta: `revision ${item.desiredRevision}`,
                        status: item.desiredState,
                      },
                      {
                        label: "Worker projection",
                        meta:
                          workspace.jobs.find((job) => job.subjectId === item.deploymentId)
                            ?.status ?? "not observed",
                      },
                      {
                        label: "Runtime process",
                        meta:
                          (processes.data ?? []).find((p) => p.deploymentId === item.deploymentId)
                            ?.observedHealth ?? "missing",
                      },
                      {
                        label: "Observed convergence",
                        meta: item.converged ? "complete" : "pending",
                        status: item.status,
                      },
                    ]}
                  />
                </section>
              </div>
            </>
          ) : null}
          {section === "edit" ? (
            <section className="panel">
              <h2>编辑 Deployment</h2>
              <ContractBoundaryNote>
                V1 不提供通用编辑。运行状态通过 start/stop/restart/reconcile，副本通过
                scale；Runtime Version 和绑定 Profile 只读。
              </ContractBoundaryNote>
              <KeyValueList
                entries={[
                  ["Runtime Version", item.runtimeVersion],
                  ["Database Profile", item.databaseProfileId],
                  ["Config Profile", item.configProfileId],
                  ["Adapter Endpoint", "由 Provider/创建快照决定"],
                ]}
              />
            </section>
          ) : null}
          {section === "reconciliation" ? (
            <section className="panel">
              <h2>Reconciliation Timeline</h2>
              <Timeline
                items={[
                  ...workspace.operations
                    .filter((op) => op.subjectId === item.deploymentId)
                    .flatMap((op) =>
                      op.timeline.map((label, index) => ({
                        label,
                        meta: `${op.operationId} · step ${index + 1}`,
                        status: String(op.status),
                      })),
                    ),
                  {
                    label: "Current desired snapshot",
                    meta: `revision ${item.desiredRevision}`,
                    status: item.status,
                  },
                ]}
              />
              <Button
                variant="primary"
                busy={reconcile.isPending}
                onClick={() => command("reconcile")}
              >
                重新对账
              </Button>
            </section>
          ) : null}
          {section === "instances" ? (
            <section className="panel">
              <DataTable
                columns={[
                  "Instance",
                  "Process",
                  "Readiness",
                  "Registration",
                  "Health",
                  "Observed Revision",
                ]}
                rows={(processes.data ?? [])
                  .filter((p) => p.deploymentId === item.deploymentId)
                  .map((p) => [
                    <button
                      className="table-link"
                      onClick={() =>
                        navigate(`/runtime/instances/${item.providerId}/${p.instanceId}`)
                      }
                    >
                      {p.instanceId}
                    </button>,
                    p.processState,
                    p.readinessState,
                    p.registrationState,
                    <StatusBadge status={p.observedHealth} />,
                    p.observedRevision,
                  ])}
              />
            </section>
          ) : null}
          {section === "configuration" ? (
            <section className="panel">
              <h2>Configuration Target</h2>
              <p>
                <code>{item.configProfileId}</code>
              </p>
              <DataTable
                columns={["Draft", "Status", "Version", "Apply Mode"]}
                rows={(drafts.data ?? [])
                  .filter((d) => d.targetLabel.includes(item.deploymentId))
                  .map((d) => [
                    <button
                      className="table-link"
                      onClick={() => navigate(`/configuration/${d.draftId}`)}
                    >
                      {d.draftId}
                    </button>,
                    <StatusBadge status={d.status} />,
                    d.version,
                    d.applyMode ?? "—",
                  ])}
              />
            </section>
          ) : null}
          {section === "activity" ? (
            <section className="panel">
              <DataTable
                columns={["Action", "Actor", "Correlation", "Time"]}
                rows={(audit.data ?? [])
                  .filter((a) => a.subjectId === item.deploymentId)
                  .map((a) => [a.action, a.actorId, <code>{a.correlationId}</code>, a.occurredAt])}
              />
            </section>
          ) : null}
          {section === "scale" ? (
            <section className="panel narrow-form">
              <h2>Scale RuntimeDeployment</h2>
              <ContractBoundaryNote>
                当前业务只允许 desiredReplicas 只能取 0 或 1。没有任意多副本 Slider。
              </ContractBoundaryNote>
              <FormField label="Desired Replicas">
                <select
                  value={replicas}
                  onChange={(e) => setReplicas(Number(e.target.value) as 0 | 1)}
                >
                  <option value={1}>1 · running</option>
                  <option value={0}>0 · stopped</option>
                </select>
              </FormField>
              <KeyValueList
                entries={[
                  ["Current", item.desiredReplicas],
                  ["expectedDesiredRevision", item.desiredRevision],
                  ["Target", replicas],
                ]}
              />
              <Button
                variant={replicas === 0 ? "danger" : "primary"}
                onClick={() =>
                  replicas === 0
                    ? setConfirm("scale0")
                    : scale.mutate(
                        {
                          deploymentId: item.deploymentId,
                          providerId: item.providerId,
                          expectedDesiredRevision: item.desiredRevision,
                          desiredReplicas: 1,
                        },
                        {
                          onSuccess: (intent) =>
                            workspaceStore.recordIntent(
                              "runtime.scale",
                              item.deploymentId,
                              intent.operationId,
                            ),
                        },
                      )
                }
              >
                Scale to {replicas}
              </Button>
              <MutationFeedback mutation={scale} />
            </section>
          ) : null}
          {section === "upgrade" ? (
            <DeferredCapability
              title="Runtime Upgrade Plan"
              reason="Console API V1 does not expose upgrade command."
            >
              <div className="grid-two">
                <section>
                  <FormField label="Target Release">
                    <select>
                      <option>2.1.0-candidate</option>
                      <option>2.0.0-rc.1</option>
                    </select>
                  </FormField>
                  <FormField label="Maintenance Window">
                    <input defaultValue="2026-08-01 02:00–02:30 UTC" />
                  </FormField>
                  <FormField label="Rollback Release">
                    <input defaultValue={item.runtimeVersion} />
                  </FormField>
                </section>
                <section>
                  <h3>Local risk assessment</h3>
                  <ul>
                    <li>Provider Package compatibility: review required</li>
                    <li>Configuration apply mode: restart_required</li>
                    <li>Expected interruption: 30–60 seconds</li>
                  </ul>
                  <Button
                    onClick={() =>
                      sessionStorage.setItem(`upgrade-plan:${item.deploymentId}`, "saved")
                    }
                  >
                    保存本地升级计划
                  </Button>
                </section>
              </div>
              <Button
                variant="primary"
                disabled
                title="Console API V1 does not expose upgrade command"
              >
                Execute upgrade unavailable
              </Button>
            </DeferredCapability>
          ) : null}
          <ConfirmDialog
            open={confirm !== null}
            title={confirm === "restart" ? "确认重启 Runtime" : "确认停止 Runtime"}
            impact={
              <ul>
                <li>当前 desiredRevision: {item.desiredRevision}</li>
                <li>提交后返回 202 Intent，不代表立即完成</li>
                <li>
                  {confirm === "scale0" ? "desiredReplicas 将设为 0" : "Runtime 可能短暂不可用"}
                </li>
              </ul>
            }
            requirePhrase={item.deploymentId}
            reasonRequired
            busy={stop.isPending || restart.isPending || scale.isPending}
            onCancel={() => setConfirm(null)}
            onConfirm={() => {
              if (confirm === "restart") command("restart");
              else if (confirm === "scale0")
                scale.mutate(
                  {
                    deploymentId: item.deploymentId,
                    providerId: item.providerId,
                    expectedDesiredRevision: item.desiredRevision,
                    desiredReplicas: 0,
                  },
                  {
                    onSuccess: (intent) =>
                      workspaceStore.recordIntent(
                        "runtime.scale",
                        item.deploymentId,
                        intent.operationId,
                      ),
                  },
                );
              else command("stop");
              setConfirm(null);
            }}
          />
          <MutationFeedback mutation={start} />
          <MutationFeedback mutation={stop} />
          <MutationFeedback mutation={restart} />
          <MutationFeedback mutation={reconcile} />
        </ProductPage>
      )}
    </QuerySurface>
  );
}

type InstanceSection = "overview" | "registration" | "configuration" | "activity";
export function RuntimeInstancesPage({
  detail = false,
  section = "overview",
}: {
  readonly detail?: boolean;
  readonly section?: InstanceSection;
}) {
  const { providerId = "", runtimeId = "" } = useParams();
  const processes = useProcesses();
  const process = useProcess(providerId, runtimeId);
  const audit = useAuditEvents({ subjectId: runtimeId });
  if (!detail)
    return (
      <ProductPage
        title="Runtime Instances"
        description="RuntimeProcess 与 RuntimeDeployment 的前端组合视图；没有独立 Instance 写接口。"
        classification="WEB_COMPOSED"
      >
        <section className="panel">
          <QuerySurface query={processes}>
            {(items) => (
              <DataTable
                columns={[
                  "Instance",
                  "Deployment",
                  "Process",
                  "Registration",
                  "Health",
                  "Config Revision",
                  "Heartbeat",
                ]}
                rows={items.map((item) => [
                  <button
                    className="table-link"
                    onClick={() =>
                      navigate(`/runtime/instances/${item.providerId}/${item.instanceId}`)
                    }
                  >
                    {item.instanceId}
                  </button>,
                  item.deploymentId,
                  item.processState,
                  item.registrationState,
                  <StatusBadge status={item.observedHealth} />,
                  item.configRevision,
                  item.lastHeartbeatAt,
                ])}
              />
            )}
          </QuerySurface>
        </section>
      </ProductPage>
    );
  return (
    <QuerySurface query={process}>
      {(item) => (
        <ProductPage
          title={item.instanceId}
          description={`${item.deploymentId} · ${item.runtimeVersion}`}
          classification="WEB_COMPOSED"
        >
          <Tabs
            current={section}
            onChange={(id) =>
              navigate(`/runtime/instances/${item.providerId}/${item.instanceId}/${id}`)
            }
            items={[
              { id: "overview", label: "概览" },
              { id: "registration", label: "Registration" },
              { id: "configuration", label: "Configuration" },
              { id: "activity", label: "Activity" },
            ]}
          />
          {section === "overview" ? (
            <div className="grid-two">
              <section className="panel">
                <KeyValueList
                  entries={[
                    ["Process State", item.processState],
                    ["Readiness", item.readinessState],
                    ["Registration", item.registrationState],
                    ["Catalog", item.catalogState],
                    ["Observed Health", <StatusBadge status={item.observedHealth} />],
                    ["Ready for ACTIVE", String(item.readyForActive)],
                  ]}
                />
              </section>
              <section className="panel">
                <Timeline
                  items={[
                    { label: "Process", status: item.processState },
                    { label: "Health", status: item.observedHealth },
                    { label: "Registration", status: item.registrationState },
                    { label: "Catalog", status: item.catalogState },
                  ]}
                />
              </section>
            </div>
          ) : section === "registration" ? (
            <section className="panel">
              <h2>Registration projection</h2>
              <KeyValueList
                entries={[
                  ["State", item.registrationState],
                  ["Freshness", item.registrationState],
                  ["Heartbeat", item.lastHeartbeatAt],
                  ["Observed Revision", item.observedRevision],
                ]}
              />
            </section>
          ) : section === "configuration" ? (
            <section className="panel">
              <h2>Runtime configuration observation</h2>
              <KeyValueList
                entries={[
                  ["Config Revision", item.configRevision],
                  ["Runtime Version", item.runtimeVersion],
                  ["Restart Count", item.restartCount],
                ]}
              />
              <p>合同不提供独立 Runtime ACK 管理接口；此页只展示 RuntimeProcess 已有投影。</p>
            </section>
          ) : (
            <section className="panel">
              <DataTable
                columns={["Action", "Actor", "Time"]}
                rows={(audit.data ?? [])
                  .filter(
                    (a) => a.subjectId === item.instanceId || a.subjectId === item.deploymentId,
                  )
                  .map((a) => [a.action, a.actorId, a.occurredAt])}
              />
            </section>
          )}
        </ProductPage>
      )}
    </QuerySurface>
  );
}

export function RuntimeProcessesPage({ detail = false }: { readonly detail?: boolean }) {
  const { providerId = "", processId = "" } = useParams();
  const list = useProcesses();
  const detailQuery = useProcess(providerId, processId);
  if (!detail)
    return (
      <ProductPage
        title="Runtime Processes"
        description="进程、应用健康、注册和 Catalog 是相互独立的状态面。"
        classification="FROZEN_API"
      >
        <section className="panel">
          <QuerySurface query={list}>
            {(items) => (
              <DataTable
                columns={[
                  "Process",
                  "Deployment",
                  "State",
                  "Readiness",
                  "Registration",
                  "Catalog",
                  "Health",
                  "Heartbeat",
                ]}
                rows={items.map((item) => [
                  <button
                    className="table-link"
                    onClick={() =>
                      navigate(`/runtime/processes/${item.providerId}/${item.instanceId}`)
                    }
                  >
                    {item.instanceId}
                  </button>,
                  item.deploymentId,
                  item.processState,
                  item.readinessState,
                  item.registrationState,
                  item.catalogState,
                  <StatusBadge status={item.observedHealth} />,
                  item.lastHeartbeatAt,
                ])}
              />
            )}
          </QuerySurface>
        </section>
      </ProductPage>
    );
  return (
    <QuerySurface query={detailQuery}>
      {(item) => (
        <ProductPage
          title={item.instanceId}
          description="RuntimeProcess 冻结详情；无直接 PM2 控制命令。"
          classification="FROZEN_API"
        >
          <div className="process-state-groups">
            <section>
              <small>Supervisor process</small>
              <strong>{item.processState}</strong>
              <p>不等于应用健康。</p>
            </section>
            <section>
              <small>Application readiness</small>
              <strong>{item.readinessState}</strong>
              <p>用于 ACTIVE 收敛判断。</p>
            </section>
            <section>
              <small>Platform registration</small>
              <strong>{item.registrationState}</strong>
              <p>独立于 PM2 online。</p>
            </section>
            <section>
              <small>Catalog projection</small>
              <strong>{item.catalogState}</strong>
              <p>由发现与 Registry 收口产生。</p>
            </section>
          </div>
          <section className="panel">
            <CodeOrJsonViewer value={item} />
          </section>
        </ProductPage>
      )}
    </QuerySurface>
  );
}

const releases = [
  {
    id: "runtime-2.0.0-rc.1",
    version: "2.0.0-rc.1",
    channel: "release-candidate",
    compatibility: "frozen_v1",
    usage: 2,
  },
  {
    id: "runtime-1.9.4",
    version: "1.9.4",
    channel: "stable",
    compatibility: "legacy-adapter",
    usage: 0,
  },
];
export function RuntimeReleasesPage({
  mode,
}: {
  readonly mode: "list" | "new" | "detail" | "compatibility" | "usage";
}) {
  const { releaseId = "" } = useParams();
  const item = releases.find((x) => x.id === releaseId) ?? releases[0];
  if (mode === "new")
    return (
      <ProductPage
        title="注册 Runtime Release"
        description="完整本地制品检查；提交能力未冻结。"
        classification="DEFERRED"
      >
        <DeferredForm
          title="Runtime Release 注册"
          reason="Console API V1 does not expose Runtime Release management."
          fields={[
            { label: "Version", value: "2.1.0" },
            { label: "Artifact", value: "runtime-2.1.0.tgz" },
            { label: "Checksum", value: "local SHA-256" },
            { label: "Compatibility", value: "frozen_v1", kind: "select" },
          ]}
        />
      </ProductPage>
    );
  if (mode === "list")
    return (
      <ProductPage
        title="Runtime Releases"
        description="已知 Fixture 的版本、兼容性和使用情况；不是 Console API 数据。"
        classification="DEFERRED"
        actions={<Button onClick={() => navigate("/runtime/releases/new")}>注册检查</Button>}
      >
        <section className="panel">
          <DataTable
            columns={["Release", "Version", "Channel", "Compatibility", "Usage"]}
            rows={releases.map((x) => [
              <button className="table-link" onClick={() => navigate(`/runtime/releases/${x.id}`)}>
                {x.id}
              </button>,
              x.version,
              x.channel,
              x.compatibility,
              x.usage,
            ])}
          />
        </section>
      </ProductPage>
    );
  return (
    <ProductPage
      title={item.id}
      description="Runtime Release 本地只读产品体验。"
      classification="DEFERRED"
    >
      <Tabs
        current={mode === "detail" ? "overview" : mode}
        onChange={(id) =>
          navigate(`/runtime/releases/${item.id}/${id === "overview" ? "" : id}`.replace(/\/$/, ""))
        }
        items={[
          { id: "overview", label: "Overview" },
          { id: "compatibility", label: "Compatibility" },
          { id: "usage", label: "Usage" },
        ]}
      />
      {mode === "compatibility" ? (
        <section className="panel">
          <DataTable
            columns={["Provider Package", "Protocol", "Result", "Evidence"]}
            rows={[
              [
                "ugv-provider@1.0.0",
                "frozen_v1",
                <StatusBadge status="COMPATIBLE" />,
                "local manifest analysis",
              ],
              [
                "npc-tank-provider@1.0.0",
                "frozen_v1",
                <StatusBadge status="REVIEW" />,
                "qualification partial",
              ],
            ]}
          />
        </section>
      ) : mode === "usage" ? (
        <section className="panel">
          <DataTable
            columns={["Deployment", "Provider", "Status"]}
            rows={
              item.usage
                ? [
                    ["deploy-001", "ugv-prod-001", <StatusBadge status="ACTIVE" />],
                    ["deploy-ha-east", "ha-east-001", <StatusBadge status="ACTIVE" />],
                  ]
                : []
            }
          />
        </section>
      ) : (
        <div className="grid-two">
          <section className="panel">
            <KeyValueList
              entries={[
                ["Version", item.version],
                ["Channel", item.channel],
                ["Compatibility", item.compatibility],
                ["Usage", item.usage],
              ]}
            />
          </section>
          <DeferredCapability
            title="Release management"
            reason="No Runtime Release write API is frozen."
          >
            <Button disabled>Delete unavailable</Button>
          </DeferredCapability>
        </div>
      )}
    </ProductPage>
  );
}

const databases = [
  {
    id: "db-profile-001",
    engine: "postgresql",
    host: "db.internal",
    database: "pms_runtime",
    secretRef: "secret://runtime/ugv-prod/db",
    status: "AVAILABLE",
    usage: 1,
  },
  {
    id: "db-profile-ha",
    engine: "postgresql",
    host: "ha-db.internal",
    database: "ha_runtime",
    secretRef: "secret://runtime/ha-east/db",
    status: "AVAILABLE",
    usage: 1,
  },
];
export function DatabaseProfilesPage({
  mode,
}: {
  readonly mode: "list" | "new" | "detail" | "edit" | "usage";
}) {
  const { profileId = "" } = useParams();
  const item = databases.find((x) => x.id === profileId) ?? databases[0];
  if (mode === "new" || mode === "edit")
    return (
      <ProductPage
        title={mode === "new" ? "创建 Database Profile" : `编辑 ${item.id}`}
        description="安全 Metadata 表单；不采集密码，不模拟保存。"
        classification="DEFERRED"
      >
        <DeferredForm
          title="Database Profile"
          reason="Console API V1 does not expose Database Profile management."
          fields={[
            { label: "Profile ID", value: mode === "new" ? "db-profile-new" : item.id },
            { label: "Engine", value: item.engine, kind: "select" },
            { label: "Host", value: item.host },
            { label: "Database", value: item.database },
            { label: "SecretRef", value: item.secretRef },
          ]}
        />
      </ProductPage>
    );
  if (mode === "list")
    return (
      <ProductPage
        title="Database Profiles"
        description="安全的 Metadata Fixture；Secret 仅以 SecretRef 展示。"
        classification="DEFERRED"
        actions={<Button onClick={() => navigate("/databases/new")}>创建检查</Button>}
      >
        <section className="panel">
          <DataTable
            columns={["Profile", "Engine", "Host", "Database", "SecretRef", "Status", "Usage"]}
            rows={databases.map((x) => [
              <button className="table-link" onClick={() => navigate(`/databases/${x.id}`)}>
                {x.id}
              </button>,
              x.engine,
              x.host,
              x.database,
              <code>{x.secretRef}</code>,
              <StatusBadge status={x.status} />,
              x.usage,
            ])}
          />
        </section>
      </ProductPage>
    );
  return (
    <ProductPage
      title={item.id}
      description="Database Profile 只读 Metadata；绝不显示 Credential 值。"
      classification="DEFERRED"
    >
      <Tabs
        current={mode === "detail" ? "overview" : mode}
        onChange={(id) =>
          navigate(`/databases/${item.id}/${id === "overview" ? "" : id}`.replace(/\/$/, ""))
        }
        items={[
          { id: "overview", label: "Overview" },
          { id: "usage", label: "Usage" },
        ]}
      />
      {mode === "usage" ? (
        <section className="panel">
          <DataTable
            columns={["Deployment", "Environment", "Status"]}
            rows={[
              [
                item.id === "db-profile-001" ? "deploy-001" : "deploy-ha-east",
                "production",
                <StatusBadge status="ACTIVE" />,
              ],
            ]}
          />
        </section>
      ) : (
        <div className="grid-two">
          <section className="panel">
            <KeyValueList
              entries={[
                ["Engine", item.engine],
                ["Host", item.host],
                ["Database", item.database],
                ["SecretRef", <code>{item.secretRef}</code>],
                ["Status", <StatusBadge status={item.status} />],
              ]}
            />
          </section>
          <section className="panel">
            <h2>Secret boundary</h2>
            <p>Credential 值不进入浏览器。轮换和管理必须由外部 Secret 系统完成。</p>
            <Button onClick={() => navigate(`/secrets/${encodeURIComponent(item.secretRef)}`)}>
              查看 SecretRef 元数据
            </Button>
          </section>
        </div>
      )}
    </ProductPage>
  );
}
